const fastify = require('fastify')();
const { getQuestions } = require('./p4-module');

fastify.get('/cit/question', async (request, reply) => {
  try {
    const questions = await getQuestions();
    reply.send({
      error: '',
      statusCode: 200,
      questions,
    });
  } catch (error) {
    reply.send({
      error: error.message,
      statusCode: 500,
      questions: [],
    });
  }
});




fastify.get('/cit/answer', async (request, reply) => {
  try {
    const answers = await getAnswers();
    reply.send({
      error: '',
      statusCode: 200,
      answers,
    });
  } catch (error) {
    reply.send({
      error: error.message,
      statusCode: 500,
      answers: [],
    });
  }
});

fastify.get('/cit/question/:number', async (request, reply) => {
  try {
    const number = parseInt(request.params.number);
    const question = await getQuestion(number);
    reply.send({
      error: '',
      statusCode: 200,
      question: question.question,
      number: question.number,
    });
  } catch (error) {
    reply.send({
      error: error.message,
      statusCode: 500,
      question: '',
      number: 0,
    });
  }
});

fastify.get('/cit/answer/:number', async (request, reply) => {
  try {
    const number = parseInt(request.params.number);
    const answer = await getAnswer(number);
    reply.send({
      error: '',
      statusCode: 200,
      answer: answer.answer,
      number: answer.number,
    });
  } catch (error) {
    reply.send({
      error: error.message,
      statusCode: 500,
      answer: '',
      number: 0,
    });
  }
});

fastify.get('/cit/questionanswer/:number', (request, reply) => {
  const { number } = request.params;
  const questionAnswer = getQuestionAnswer(number);
  
  reply.code(200).send({
    error: questionAnswer.error,
    statusCode: 200,
    question: questionAnswer.question,
    answer: questionAnswer.answer,
    number: questionAnswer.number,
  });
});

fastify.get('*', (req, res) => {
  res.status(404).send({
    error: 'Route not found',
    statusCode: 404,
  });
});


fastify.listen(3000, (error) => {
  if (error) {
    console.log('Error starting server:', error);
  } else {
    console.log('Server started listening on port 3000');
  }
});